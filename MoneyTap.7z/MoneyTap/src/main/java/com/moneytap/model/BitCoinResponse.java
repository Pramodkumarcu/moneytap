package com.moneytap.model;

// Bean class to send the response back to the caller in case of success, failure.

public class BitCoinResponse {

	private double average;
	private String typeName;
	private String currency;
	private String message;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public double getAverage() {
		return average;
	}
	public void setAverage(double sumPrice) {
		this.average = sumPrice;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	
}
