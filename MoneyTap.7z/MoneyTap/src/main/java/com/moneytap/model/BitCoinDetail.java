package com.moneytap.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/*
 * BitCoinDetail Bean class to hold the information regarding the each element,
 * which we retrive from the server - Bitmex
 * 
 */



@JsonIgnoreProperties(ignoreUnknown = true)
public class BitCoinDetail {
   
//	timestamp: "2017-01-01T00:00:00.000Z",
//	symbol: ".XBTUSDPI",
//	side: "Buy",
//	size: 0,
//	price: 0.002924,
//	tickDirection: "PlusTick",
//	trdMatchID: "00000000-0000-0000-0000-000000000000",
//	grossValue: null,
//	homeNotional: null,
//	foreignNotional: null
//	

    private String timestamp;
    private String symbol;
    private String tickDirection;
    private String trdMatchID;
    private String grossValue;
    private String homeNotional;
    private String foreignNotional;
    private String side;
    private double price;
    private int size;
    
        
	public BitCoinDetail() {
		super();
	}


	@Override
	public String toString() {
		return "BitCoinDetail [timestamp=" + timestamp + ", symbol=" + symbol + ", tickDirection=" + tickDirection
				+ ", trdMatchID=" + trdMatchID + ", grossValue=" + grossValue + ", homeNotional=" + homeNotional
				+ ", foreignNotional=" + foreignNotional + ", side=" + side + ", price=" + price + ", size=" + size
				+ "]";
	}


	public BitCoinDetail(String timestamp, String symbol, String tickDirection, String trdMatchID, String grossValue,
			String homeNotional, String foreignNotional, String side, double price, int size) {
		super();
		this.timestamp = timestamp;
		this.symbol = symbol;
		this.tickDirection = tickDirection;
		this.trdMatchID = trdMatchID;
		this.grossValue = grossValue;
		this.homeNotional = homeNotional;
		this.foreignNotional = foreignNotional;
		this.side = side;
		this.price = price;
		this.size = size;
	}
	
	
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getTickDirection() {
		return tickDirection;
	}
	public void setTickDirection(String tickDirection) {
		this.tickDirection = tickDirection;
	}
	public String getTrdMatchID() {
		return trdMatchID;
	}
	public void setTrdMatchID(String trdMatchID) {
		this.trdMatchID = trdMatchID;
	}
	public String getGrossValue() {
		return grossValue;
	}
	public void setGrossValue(String grossValue) {
		this.grossValue = grossValue;
	}
	public String getHomeNotional() {
		return homeNotional;
	}
	public void setHomeNotional(String homeNotional) {
		this.homeNotional = homeNotional;
	}
	public String getForeignNotional() {
		return foreignNotional;
	}
	public void setForeignNotional(String foreignNotional) {
		this.foreignNotional = foreignNotional;
	}
	public String getSide() {
		return side;
	}
	public void setSide(String side) {
		this.side = side;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}




}
