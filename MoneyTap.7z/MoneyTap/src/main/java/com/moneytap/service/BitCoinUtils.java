package com.moneytap.service;

// This was initially planned to send the response by building it, so that error handling would be more informative.
// due to time constraint, not used this yet



//import com.fasterxml.jackson.annotation.JsonInclude.Include;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//
//public class BitCoinUtils {
//
//	  public String convertJavaToJson(Object obj) throws Exception {
//	        ObjectMapper mapper = new ObjectMapper();
//	     //   mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
//	        mapper.setSerializationInclusion(Include.NON_NULL);
//	        String jsonInString;
//	        jsonInString = mapper.writeValueAsString(obj);
//	        return jsonInString;
//	    }
//	    
////	        public Response buildResponse(Response.Status status, String entity) {
////	        return Response.status(status).entity(entity).header("Access-Control-Allow-Origin", "*")
////	                .header("Access-Control-Allow-Methods", "POST, GET, OPTIONS, HEAD")
////	                .header("Access-Control-Allow-Headers", "X-Requested-With")
////	                .header("Content-Type", "application/json")
////	                .build();
////	    } 
//	
//	
//}
