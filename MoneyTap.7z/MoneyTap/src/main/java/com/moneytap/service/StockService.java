package com.moneytap.service;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.moneytap.model.BitCoinDetail;

@Service
public class StockService {
	public StockService() {
	}
	
	public List<BitCoinDetail> getDetail(int duration) {
	
		 SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
		 Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("www-proxy-idc.in.oracle.com", 80));
		 clientHttpRequestFactory.setProxy(proxy);
		// Calculating the start time interval in ISO 8601 format by deleting the time interval passed in the Parameter
		 
		 Calendar timeStamp = Calendar.getInstance();
		 timeStamp.setTimeInMillis(timeStamp.getTimeInMillis());
		 timeStamp.add(Calendar.MINUTE, -duration);
		 DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	     String startTimeStamp = df.format(timeStamp.getTime());
	    
	     String endTimeStamp = df.format(new Date());
         
	     // building the URI as per the time interval based on the Parameter passed in the GET call
		 String uri = "https://www.bitmex.com/api/v1/trade?symbol=XBTUSD&count=200&startTime="+startTimeStamp+"&endTime="+endTimeStamp;

	     RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
	     // consuming the output for the GET call from bitmex and storing it as a list of objects 
	     // and later will be used to calculate the average, median,... 
	     
	     ResponseEntity<List<BitCoinDetail>> response = restTemplate.exchange(
	    		 uri, HttpMethod.GET, null, new ParameterizedTypeReference<List<BitCoinDetail>>(){});
	     List<BitCoinDetail> btcList = response.getBody();
   
		 return btcList;
		
	}
	

}
