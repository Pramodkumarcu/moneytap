package com.moneytap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 * Creating MoneyTapApplication using SpringBoot and creating REST API's with Average and Median functionality
 * Using "https://www.bitmex.com/api" for retrieving the real time information,
 * since the Bitmex will not have recent 1000 Min information, please review accordingly
 */

@SpringBootApplication
public class MoneyTapApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoneyTapApplication.class, args);
	}
}
