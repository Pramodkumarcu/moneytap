package com.moneytap.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.moneytap.model.BitCoinDetail;
import com.moneytap.model.BitCoinResponse;
import com.moneytap.service.StockService;

@RestController
@RequestMapping("/bitcoin")
public class StockController {
	
	// injecting StockService into the Controller
	
     @Autowired   
    StockService stockService;
 
 @RequestMapping(value = "/average", method = RequestMethod.GET)
 public BitCoinResponse getAveragePrice(@RequestParam("durationInMins") int duration){
	 double sumPrice=0;
	 BitCoinResponse bitcoinResponse = new BitCoinResponse(); 
	 List<BitCoinDetail> btcList = stockService.getDetail(duration);
	 for(BitCoinDetail iter : btcList)
	    {
		 // Calculating the average accross the time interval - duration in Min
		 
		  sumPrice = sumPrice + iter.getPrice();
	    }
	 bitcoinResponse.setCurrency("$");
	 bitcoinResponse.setTypeName("XBTUSD");
	 // We have already filtered for only Bitcoin and in USD - $ in the URI, so hardcoding it to XBTUSD
	 
     if(btcList.size()>0) {
    	 // building the response for the GET call incase of success
		 sumPrice = sumPrice/btcList.size();
		 bitcoinResponse.setAverage(sumPrice);
		 bitcoinResponse.setMessage("Successfully calculated the average");
		 return bitcoinResponse;
	 }
     // building the response for the GET call incase of failure
	 bitcoinResponse.setAverage(-1);
	 bitcoinResponse.setMessage("No Records/ transactions found within the provided interval");
	 
	 // Returning -1, incase of No Records
	 
	return bitcoinResponse;
}
}
